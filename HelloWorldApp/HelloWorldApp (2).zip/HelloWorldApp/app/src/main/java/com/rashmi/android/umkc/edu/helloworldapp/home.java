package com.rashmi.android.umkc.edu.helloworldapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by chanu on 10/21/2017.
 */

public class home extends AppCompatActivity{

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);
    }


}
